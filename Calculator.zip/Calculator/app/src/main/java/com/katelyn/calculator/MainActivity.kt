package com.katelyn.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView



class MainActivity : AppCompatActivity() {

    lateinit var displayResult: TextView
    lateinit var edtFirst : EditText
    lateinit var edtSecond : EditText
    lateinit var addition : Button
    lateinit var subtraction : Button
    lateinit var multiplication : Button
    lateinit var division : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //access the IDs by using a View

        displayResult = findViewById(R.id.displayResult)
        edtFirst = findViewById(R.id.edtFirst)
        edtSecond = findViewById(R.id.edtSecond)
        addition = findViewById(R.id.addition)
        subtraction = findViewById(R.id.subtraction)
        multiplication = findViewById(R.id.multiplication)
        division = findViewById(R.id.division)



        addition.setOnClickListener {
            val res1 = edtFirst.text.toString().toInt()
            val res2 = edtSecond.text.toString().toInt()
            addition(res1, res2)
        }

        subtraction.setOnClickListener {
            val res1 = edtFirst.text.toString().toInt()
            val res2 = edtSecond.text.toString().toInt()
            subtraction(res1, res2)
        }

       multiplication.setOnClickListener {
           val res1 = edtFirst.text.toString().toInt()
           val res2 = edtSecond.text.toString().toInt()
           multiplication(res1, res2)
        }

        division.setOnClickListener {
            val res1 = edtFirst.text.toString().toInt()
            val res2 = edtSecond.text.toString().toInt()
            division(res1, res2)
        }
    }

    private fun addition(res1: Int, res2: Int)
    {
        val result = res1 + res2
        displayResult.text = result.toString()
    }
    private fun subtraction(res1: Int, res2: Int)
    {
        val result = res1 - res2
        displayResult.text = result.toString()
    }
    private fun multiplication(res1: Int, res2: Int)
    {
        val result = res1 * res2
        displayResult.text = result.toString()
    }
    private fun division(res1: Int, res2: Int)
    {
        val result = res1 / res2
        displayResult.text = result.toString()
    }
}